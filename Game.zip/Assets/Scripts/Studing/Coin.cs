using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    [SerializeField] private float rotationSpeed = 45.0f;
    void Start()
    {
        
    }

    void Update()
    {
        Vector3 currentRotation = transform.eulerAngles;
        currentRotation.y += rotationSpeed * Time.deltaTime;
        transform.eulerAngles = currentRotation;
    }
}
